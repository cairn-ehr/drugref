COPY public.reference (id, pmid, doi, document_id, type, authors, title, isbn10, url, journal, volume, issue, dp_year, pages) FROM stdin;
1	\N	\N	\N	BOOK	Karen Baxter	Stockley's Drug Interactions	0853699143	\N	\N	\N	\N	2010	\N
2	\N	\N	\N	ONLINE RESOURCE	Veterans Health Administration	Veterans Health Administration (VHA) National Drug File - Reference Terminology (NDF-RT)	\N	http://www.cancer.gov/cancertopics/cancerlibrary/terminologyresources/fmt	\N	\N	\N	\N	\N
3	\N	\N	\N	ONLINE RESOURCE	Wolters Kluwer Health	Lexicomp Online	\N	http://www.lexi.com	\N	\N	\N	\N	\N
\.
COPY public.structures (id, name, cas_reg_no, inchikey, status) FROM stdin;
52	paracetamol	103-90-2	RZVAJINKPMORJF-UHFFFAOYSA-N	OFP
2179	pioglitazone	111025-46-8	HYAFETHFCAUJAY-UHFFFAOYSA-N	OFP
1280	gatifloxacin	112811-59-3	XUBOMFCQGDBHNK-UHFFFAOYSA-N	OFP
2528	sulfinpyrazone	57-96-5	MBGGBVCUIVRRBF-UHFFFAOYSA-N	OFM
2376	rifabutin	72559-06-9	ATEBXHFBFRCZMA-VXTBVIBXSA-N	OFP
\.
COPY public.synonyms (syn_id, id, name, preferred_name, parent_id, lname) FROM stdin;
1853	52	acetaminophen	\N	\N	acetaminophen
\.
COPY public.ddi (id, drug_class1, drug_class2, ddi_ref_id, ddi_risk, description, source_id) FROM stdin;
15	gatifloxacin	pioglitazone	2	Critical	GATIFLOXACIN/PIOGLITAZONE HCL [VA Drug Interaction]	C23308143128526
870	acetaminophen	sulfinpyrazone	2	Significant	ACETAMINOPHEN/SULFINPYRAZONE [VA Drug Interaction]	C23303775029507
1288	cortisone	rifabutin	2	Significant	CORTISONE/RIFABUTIN [VA Drug Interaction]	C23304976819400
2890	pioglitazone	gatifloxacin	2	Significant	GATIFLOXACIN/PIOGLITAZONE [VA Drug Interaction]	C56^4265^
15517	Monoamine Oxidase Inhibitors	Alpha/Beta Agonists	3	Potentially significant	[redacted: cites a reference CLAUDE.md rule 6 excludes]	MAO Inhibitors - Alpha/Beta-Agonists
15522	Monoamine Oxidase Inhibitors	buspirone	1	Potentially significant	[redacted: cites a reference CLAUDE.md rule 6 excludes]	MAOIs or RIMAs + Buspirone
15523	Monoamine Oxidase Inhibitors	dextromethorphan	1	Contraindicated	[redacted: cites a reference CLAUDE.md rule 6 excludes]	MAOIs or RIMAs + Dextromethorphan
15535	conivaptan	CYP3A4 Substrates	3	Avoid combination	[redacted: cites a reference CLAUDE.md rule 6 excludes]	Conivaptan: CYP3A4 Substrates
\.
